#include "geo.h"

struct point makepoint(double x,double y)
{
    struct point temp;
    temp.x=x;
    temp.y=y;
    return temp;
};
