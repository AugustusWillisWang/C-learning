#include <stdio.h>
#define paste(front,back) front ## back
int main()
{
    paste(pri,ntf)("helloworld\n");
    return 0;
}

