#include <stdio.h>
int a,b,c;
int main()
{
    int d,e,f;
    printf("addr_of_a =%p\n",&a);
    printf("addr_of_b =%p\n",&b);
    printf("addr_of_c =%p\n",&c);
    printf("addr_of_d =%p\n",&d);
    printf("addr_of_e =%p\n",&e);
    printf("addr_of_f =%p\n",&f);
    return 0;
}
